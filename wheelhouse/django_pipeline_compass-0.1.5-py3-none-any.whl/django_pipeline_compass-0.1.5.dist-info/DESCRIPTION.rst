django-pipeline compiler for scss and with compass. Does not require the ruby gem.

Home-page: https://github.com/vbabiy/django-pipeline-compass
Author: Vitaly
Author-email: vbabiy86@gmail.com
License: UNKNOWN
Description: 
        django-pipeline compiler for scss and with compass. Does not require the ruby gem.
        
Platform: UNKNOWN
Classifier: Environment :: Web Environment
Classifier: Intended Audience :: Developers
Classifier: License :: OSI Approved :: MIT License
Classifier: Operating System :: OS Independent
Classifier: Programming Language :: Python
Classifier: Topic :: Utilities
