DRF-extensions is a collection of custom extensions for Django REST Framework


