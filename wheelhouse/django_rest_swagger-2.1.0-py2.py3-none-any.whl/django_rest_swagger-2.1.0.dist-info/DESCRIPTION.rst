
Django REST Swagger

An API documentation generator for Swagger UI and Django REST Framework.

Installation
>From pip:

pip install django-rest-swagger

Project @ https://github.com/marcgibbons/django-rest-swagger
Docs @ https://django-rest-swagger.readthedocs.io/


